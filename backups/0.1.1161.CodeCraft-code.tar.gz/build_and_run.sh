#!/bin/bash
sh build.sh
cd bin

fix=$1
./CodeCraft-2019 ../config$fix/car.txt ../config$fix/road.txt ../config$fix/cross.txt ../config$fix/answer.txt

### test ###
#vars=("" "_1" "_2" "_3" "_4" "_5" "_6" "_7" "_8" "_9" "_10" "_0")
#for((i=0;i<${#vars[*]};i++))
#do
#fix=${vars[i]}
#echo "test"$fix
#./CodeCraft-2019 ../config$fix/car.txt ../config$fix/road.txt ../config$fix/cross.txt ../config$fix/answer.txt
#done
