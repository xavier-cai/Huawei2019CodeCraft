#include "config.h"
#include "scenario.h"
#include "log.h"

#include "assert.h"
#include "timer.h"
#include "simulator.h"
#include "sim-scenario.h"

#include <list>
#include <set>
#include <map>
#include "pmap.h"
#include "random.h"

#include <cstdlib>
#define lenthWeight  0.2
#define carNumWeight  0.8
std::pmap<double, int, int> crosslength;
std::pmap<int, int, int> crosspath;
std::pmap<int, int, int> minlength;
std::pmap<std::list<int>,int,int> minpath;
//crossLength[std::make_pair(1, 1)] = 3;
int crossidfirst;
int crossidsecond;
void Floydmodel(SimScenario& scenario)
{
    for (auto itefirst = Scenario::Crosses().begin(); itefirst != Scenario::Crosses().end(); itefirst++)
    {
        crossidfirst = itefirst->first;
        for (auto itesecond = Scenario::Crosses().begin(); itesecond != Scenario::Crosses().end(); itesecond++)
        {
            crossidsecond = itesecond->first;
            crosslength[std::make_pair(crossidfirst, crossidsecond)] = 10000;
            crosspath[std::make_pair(crossidfirst, crossidsecond)] = crossidsecond;
        }
    }
    for (auto itefirst = Scenario::Crosses().begin(); itefirst != Scenario::Crosses().end(); itefirst++)
    {
        for (int i = (int)Cross::NORTH; i <= (int)Cross::WEST; i++)
        {
            Road* road = itefirst->second->GetRoad((Cross::DirectionType)i);
            if (road != 0)
            {
                SimRoad* roadlink = &scenario.Roads()[road->GetId()];
                if (roadlink->GetRoad()->GetStartCrossId() == itefirst->first ||
                    (roadlink->GetRoad()->GetEndCrossId() == itefirst->first && roadlink->GetRoad()->GetIsTwoWay()))
                {
                    Cross* peerlink = roadlink->GetRoad()->GetPeerCross(itefirst->second);
                    int carAver = 0;
                    for (int j = 1; j <= roadlink->GetRoad()->GetLanes(); j++)
                    {
                        carAver += roadlink->GetCarsFrom(j, itefirst->first).size();
                    }
                    carAver = carAver/roadlink->GetRoad()->GetLanes();
                    int roadLength = itefirst->second->GetRoad((Cross::DirectionType)i)->GetLength();
                    crosslength[std::make_pair(itefirst->first, peerlink->GetId())] = roadLength * lenthWeight + carAver * carNumWeight;
                }
            }
        }
    }
    for (auto iteTransfer = Scenario::Crosses().begin(); iteTransfer != Scenario::Crosses().end(); iteTransfer++)
    {
        for (auto iteRow = Scenario::Crosses().begin(); iteRow != Scenario::Crosses().end(); iteRow++)
        {
            for (auto iteColumn = Scenario::Crosses().begin(); iteColumn != Scenario::Crosses().end(); iteColumn++)
            {
                int lengthAfterTran = crosslength[std::make_pair(iteRow->first, iteTransfer->first)] + crosslength[std::make_pair(iteTransfer->first, iteColumn->first)];
                if (crosslength[std::make_pair(iteRow->first, iteColumn->first)] > lengthAfterTran)
                {
                    crosslength[std::make_pair(iteRow->first, iteColumn->first)] = lengthAfterTran;

                    crosspath[std::make_pair(iteRow->first, iteColumn->first)] = iteTransfer->first;
                }
            }
        }
    }
    for (auto iteStart = Scenario::Crosses().begin(); iteStart != Scenario::Crosses().end(); iteStart++)
    {
        for (auto iteEnd = Scenario::Crosses().begin(); iteEnd != Scenario::Crosses().end(); iteEnd++)
        {
            minlength[std::make_pair(iteStart->first, iteEnd->first)] = crosslength[std::make_pair(iteStart->first, iteEnd->first)];
            int startstep = iteStart->first;
            
            std::list<int> pathlist;
            std::list<int> crosslist;
            while (startstep != iteEnd->first)
            {
                int transstep = crosspath[std::make_pair(startstep, iteEnd->first)];
                while (crosspath[std::make_pair(startstep, transstep)] != transstep)
                {
                    transstep = crosspath[std::make_pair(startstep, transstep)];

                }
                startstep = transstep;
                crosslist.push_back(startstep);
            }
            //trans crosses to roads
            Cross* lastCross = iteStart->second;
            for (auto ite = crosslist.begin(); ite != crosslist.end(); ite++)
            {
                bool consistant = false;
                Cross* thisCross = Scenario::GetCross(*ite);
                for (int i = (int)Cross::NORTH; i <= (int)Cross::WEST; i++)
                {
                    Road* road = lastCross->GetRoad((Cross::DirectionType)i);
                    if (road != 0)
                    {
                        if ((road->GetStartCrossId() == lastCross->GetId() && road->GetEndCrossId() == thisCross->GetId())
                            || (road->GetEndCrossId() == lastCross->GetId() && road->GetStartCrossId() == thisCross->GetId() && road->GetIsTwoWay()))
                        {
                            consistant = true;
                            pathlist.push_back(road->GetId());
                            break;
                        }
                    }
                }
                ASSERT_MSG(consistant, "can not find the road bewteen " << lastCross->GetId() << " and " << thisCross->GetId());
                lastCross = thisCross;
            }
            minpath[std::make_pair(iteStart->first, iteEnd->first)] = pathlist;
        }
    }
}

int main(int argc, char *argv[])
{
    //Log::Default(Log::ENABLE);
    Random::SetSeedAuto();
    Config::Initialize(argc, argv);
    Scenario::Initialize();
	SimScenario scenario;

    //system("mode con cols=140");
	for(int time = 0; true; time++) //forever until complete!
	{
        Floydmodel(scenario);
        for(auto ite = scenario.Cars().begin(); ite != scenario.Cars().end(); ite++)
	    {
            SimCar* car = &ite->second;
            if (car->GetCar()->GetFromCrossId() != car->GetCar()->GetToCrossId()
                && !car->GetIsReachedGoal())
            {
                int from = car->GetCar()->GetFromCrossId();
                if (!car->GetIsInGarage() && car->GetCurrentRoad() != 0)
                    from = car->GetCurrentCorss()->GetId();
                int to = car->GetCar()->GetToCrossId();
                auto& carTrace = car->GetTrace();
                auto* newTrace = &minpath[std::make_pair(from, to)];

                if (car->GetIsInGarage())
                    carTrace.Clear();
                else
                {
                    while (carTrace.Current() != carTrace.Tail())
                        carTrace.RemoveFromTail();
                    //drop back
                    if (carTrace.Size() > 0 && newTrace->size() > 0 && *newTrace->begin() == *--carTrace.Tail())
                    {
                        double minPath = -1;
                        int minPathId = -1;
                        int minCrossId = -1;
                        for (int i = (int)Cross::NORTH; i <= (int)Cross::WEST; i++)
                        {
                            Road* road = Scenario::GetCross(from)->GetRoad((Cross::DirectionType)i);

                            if (road != 0 && road->GetId() != car->GetCurrentRoad()->GetId())
                            {
                                if (road->GetStartCrossId() == from ||
                                (road->GetEndCrossId() == from && road->GetIsTwoWay()))
                                {
                                    Cross* nearCross = road->GetPeerCross(Scenario::GetCross(from));
                                    double newlength = minlength[std::make_pair(from, nearCross->GetId())] + minlength[std::make_pair(nearCross->GetId(),to)];
                                    if ((minPath < -0.5) ||(minPath > newlength))
                                    {
                                        minPath = newlength;
                                        minPathId = road->GetId();
                                        minCrossId = nearCross->GetId();
                                    }   
                                }
                            }
                        }
                        ASSERT(minPathId >= 0 && minCrossId >= 0);
                        carTrace.AddToTail(minPathId);
                        newTrace = &minpath[std::make_pair(minCrossId, to)];
                    }
                }

                for (auto traceIte = newTrace->begin(); traceIte != newTrace->end(); traceIte++)
                    carTrace.AddToTail(*traceIte);
            }
	    }
	    auto result = Simulator::UpdateSelf(time, scenario);
	    ASSERT(!result.Conflict);
	    if (scenario.IsComplete())
	        break;
	}
	
	scenario.SaveToFile();
	
	return 0;
}
;
