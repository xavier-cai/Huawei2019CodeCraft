#ifndef SIMULATOR_H
#define SIMULATOR_H

#include "sim-scenario.h"
#include <utility>

class Simulator
{  
public:
    struct UpdateResult
    {
        bool Conflict;

    };//struct UpdateResult

private:
    int m_time;
    SimScenario& m_scenario;

    Simulator(const int& time, SimScenario& scenario);
    UpdateResult UpdateSelf() const;

public:
    static std::pair<SimScenario, UpdateResult> Update(int time, SimScenario& scenario);
    static UpdateResult UpdateSelf(const int& time, SimScenario& scenario);
    
};//class Simulator

#endif
