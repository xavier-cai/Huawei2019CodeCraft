#include "simulator.h"

#ifndef SIMULATOR_CPP
#define SIMULATOR_CPP
bool conflictFlag = false;
int scheduledCarsN = 0;
int reachedCarsN = 0;
void NotifyUpdateStateHandler(const SimCar::SimState& state)
{
    conflictFlag = false;
    if(state == SimCar::SCHEDULED)
        scheduledCarsN++;
}
#endif //#ifndef SIMULATOR_CPP

Simulator::Simulator(const int& time, SimScenario& scenario)
    : m_time(time), m_scenario(scenario)
{
    SimCar::SetUpdateStateNotifier(&NotifyUpdateStateHandler);
}

std::pair<SimScenario, Simulator::UpdateResult> Simulator::Update(int time, SimScenario& scenario)
{
    SimScenario ret(scenario);
    auto result = UpdateSelf(time, ret);
    return std::make_pair(ret, result);
}

Simulator::UpdateResult Simulator::UpdateSelf(const int& time, SimScenario& scenario)
{
    Simulator sim(time, scenario);
    return sim.UpdateSelf();
}



#include "pmap.h"
#include <algorithm>
#include <set>
#include "scenario.h"
#include "assert.h"
#include "log.h"

template <typename _T>
std::_List_iterator<_T> operator + (const std::_List_iterator<_T>& ite, int n)
{
    auto copy = ite;
    bool opposite = n < 0;
    if (opposite) n = -n;
    while(n-- > 0)
        opposite ? copy-- : copy++;
    return copy;
}

template <typename _T>
std::_List_iterator<_T> operator - (const std::_List_iterator<_T>& ite, int n)
{
    return ite + -n;
}

enum TrunType
{
    LEFT,
    DIRECT,
    RIGHT
};

std::ostream& operator << (std::ostream& os, const TrunType& turn)
{
    switch (turn)
    {
    case LEFT: os << "Left"; break;
    case DIRECT: os << "Direct"; break;
    case RIGHT: os << "Right"; break;
    default: ASSERT(false); break;
    }
    return os;
}

std::pmap< TrunType, int, int> directions;
std::pmap< int, int, TrunType> roadPeers;
std::pmap< int, int, TrunType> roadPeersOpposite;
void InitializeDirections()
{
    directions.clear();
    for (auto crossIte = Scenario::Crosses().begin(); crossIte != Scenario::Crosses().end(); crossIte++)
    {
        Cross* cross = crossIte->second;
        for (int i = (int)Cross::NORTH; i <= (int)Cross::WEST; i++)
        {
            Road* from = cross->GetRoad((Cross::DirectionType)i);
            if (from != 0 && from->GetId() >= 0)
            {
                for (int j = (int)LEFT; j <= (int)RIGHT; j++)
                {
                    Road* to = cross->GetRoad((Cross::DirectionType)((j + i + 1) % ((int)Cross::WEST + 1)));
                    if (to != 0 && to->GetId() >= 0)
                    {
                        if ((from->GetEndCrossId() == cross->GetId() ||
                            (from->GetStartCrossId() == cross->GetId() && from->GetIsTwoWay()))
                            &&
                            (to->GetStartCrossId() == cross->GetId() ||
                            (to->GetEndCrossId() == cross->GetId() && to->GetIsTwoWay())))
                        {
                            directions[std::make_pair(from->GetId(), to->GetId())] = (TrunType)j;
                            bool isFromOrTo = to->GetStartCrossId() == cross->GetId();
                            ASSERT(isFromOrTo || to->GetEndCrossId() == cross->GetId());
                            (isFromOrTo ? roadPeers : roadPeersOpposite)[std::make_pair(to->GetId(), (TrunType)j)] = from->GetId();
                        }
                    }
                }
            }
        }
    }
}
TrunType GetDirection(int from, int to)
{
    auto find = directions.find(std::make_pair(from, to));
    ASSERT(find != directions.end());
    return find->second;
}
int GetRoadPeer(int to, TrunType dir, bool opposite)
{
    auto& map = (opposite ? roadPeersOpposite : roadPeers);
    auto find = map.find(std::make_pair(to, dir));
    if (find == map.end())
        return -1;
    return find->second;
}

//car on first priority
SimCar* PeekFirstPriorityCarOnRoad(const int& time, SimScenario& scenario, SimRoad* road, const int& crossId)
{
    SimCar* ret = 0;
    int position = road->GetRoad()->GetLength() + 1;
    for (int i = 1; i <= road->GetRoad()->GetLanes(); i++)
    {
        auto& list = road->GetCarsTo(i, crossId);
        if (list.size() > 0)
        {
            SimCar* car = &scenario.Cars()[(*list.begin())->GetId()];
            if (car->GetSimState(time) != SimCar::SCHEDULED)
            {
                if (ret == 0 || car->GetCurrentPosition() > position)
                {
                    ret = car;
                    position = car->GetCurrentPosition();
                }
            }
        }
    }
    return ret;
}

//pass cross or just forward, return [true] means scheduled; [false] means waiting, require the car is the first one on its lane
bool PassCrossOrJustForward(const int& time, SimScenario& scenario, SimCar* car)
{
    SimRoad* road = &scenario.Roads()[car->GetCurrentRoad()->GetId()];
    int maxLength = std::min(car->GetCar()->GetMaxSpeed(), road->GetRoad()->GetLimit());
    int maxNextLength = maxLength + car->GetCurrentPosition() - road->GetRoad()->GetLength();
    if (maxNextLength <= 0) //just forward
    {
        car->UpdatePosition(time, car->GetCurrentPosition() + maxLength);
        return true;
    }
    Cross* cross = car->GetCurrentCorss();
    auto& carlist = road->GetCarsTo(car->GetCurrentLane(), cross->GetId());
    ASSERT(car->GetCar() == *carlist.begin());
    int nextRoadId = car->GetNextRoadId();
    if (nextRoadId == -1) //reach goal
    {
        carlist.erase(carlist.begin());
        car->UpdateReachGoal(time);
        scenario.ReachGoal();
        reachedCarsN++;
        return true;
    }
    
    //try pass cross
    SimRoad* nextRoad = &scenario.Roads()[nextRoadId];
    bool isFromOrTo = nextRoad->IsFromOrTo(cross->GetId());
    auto direction = GetDirection(road->GetRoad()->GetId(), nextRoadId);
    if (direction != DIRECT) //check DIRECT priority
    {
        int peer = GetRoadPeer(nextRoadId, DIRECT, !isFromOrTo);
        if(peer >= 0)
        {
            SimCar* checkCar = PeekFirstPriorityCarOnRoad(time, scenario, &scenario.Roads()[peer], cross->GetId());
            if (checkCar != 0 && checkCar->GetNextRoadId() == nextRoadId)
            {
                car->UpdateWaiting(time, checkCar);
                return false;
            }
        }
    }
    if (direction == RIGHT) //check LEFT priority
    {
        int peer = GetRoadPeer(nextRoadId, LEFT, !isFromOrTo);
        if(peer >= 0)
        {
            SimCar* checkCar = PeekFirstPriorityCarOnRoad(time, scenario, &scenario.Roads()[peer], cross->GetId());
            if (checkCar != 0 && checkCar->GetNextRoadId() == nextRoadId)
            {
                car->UpdateWaiting(time, checkCar);
                return false;
            }
        }
    }
    //it's time to pass the cross!
    int nextLength = std::min(maxNextLength, nextRoad->GetRoad()->GetLimit());
    bool updatedState = false;
    for (int i = 1; i <= nextRoad->GetRoad()->GetLanes(); i++)
    {
        auto& inlist = nextRoad->GetCarsFrom(i, cross->GetId());
        SimCar* lastcar = 0;
        if (inlist.size() > 0)
            lastcar = &scenario.Cars()[(*--inlist.end())->GetId()];
        //need wait
        if (lastcar != 0 && lastcar->GetCurrentPosition() <= nextLength && lastcar->GetSimState(time) != SimCar::SCHEDULED)
        {
            car->UpdateWaiting(time, lastcar);
            updatedState = true;
            break;
        }
        //pass the cross
        if (lastcar == 0 || lastcar->GetCurrentPosition() != 1)
        {
            //go on the new road
            inlist.push_back(car->GetCar());
            int newPosition = lastcar == 0 ? nextLength : std::min(lastcar->GetCurrentPosition() - 1, nextLength);
            car->UpdateOnRoad(time, nextRoad->GetRoad(), i, isFromOrTo, newPosition);
            updatedState = true;
            break;
        }
        //try next lane...
    }
    if (!updatedState) //this means no empty place for this car in next road
    {
        car->UpdatePosition(time, road->GetRoad()->GetLength()); //just move forward
        return true;
    }
    else
    {   //scheduled means passed the cross, so...remove it!
        if (car->GetSimState(time) == SimCar::SCHEDULED)
        {
            carlist.erase(carlist.begin());
            return true;
        }
    }
    return false;
}

Simulator::UpdateResult Simulator::UpdateSelf() const
{
    int time = m_time;
    SimScenario& scenario = m_scenario;

    /* initialize global variables */
    if (directions.size() <= 0)
        InitializeDirections();
    
    UpdateResult result;
    result.Conflict = false;
    std::list<Cross*> crosses;
    for (auto ite = Scenario::Crosses().begin(); ite != Scenario::Crosses().end(); ite++)
        crosses.push_back(ite->second);
    scheduledCarsN = 0; //counter
    reachedCarsN = 0; //counter
    while(crosses.size() > 0)
    {
        conflictFlag = true; //for checking conflict
        for (auto crossIte = crosses.begin(); crossIte != crosses.end(); /* crossIte++ */)
        {
            int crossId = (*crossIte)->GetId();
            std::map<int, SimRoad*> roads; //roads in this cross
            for (int i = (int)Cross::NORTH; i <= (int)Cross::WEST; i++)
            {
                int id = (*crossIte)->GetRoadId((Cross::DirectionType)i);
                if (id >= 0)
                {

                    SimRoad* road = &scenario.Roads()[id];
                    if (road->GetRoad()->GetEndCrossId() == crossId ||
                        (road->GetRoad()->GetStartCrossId() == crossId && road->GetRoad()->GetIsTwoWay()))
                        roads[id] = road;
                }
            }
            while(roads.size() > 0)
            {
                bool crossConflict = true;
                for (auto roadIte = roads.begin(); roadIte != roads.end(); /* roadIte++ */)
                {
                    SimRoad* road = roadIte->second;
                    //try pass cross (only the first priority can pass the cross)
                    SimCar* firstPriority = 0;
                    while((firstPriority = PeekFirstPriorityCarOnRoad(time, scenario, road, crossId)) != 0)
                    {
                        auto state = firstPriority->GetSimState(time);
                        if (state == SimCar::WAITING && firstPriority->GetWaitingCar(time)->GetSimState(time) != SimCar::SCHEDULED)
                            break;
                        if (!PassCrossOrJustForward(time, scenario, firstPriority))
                            break;
                        crossConflict = false; //conflict only occurs on the first priority car
                    }
                    //try move forward other cars
                    for (int i = 1; i <= road->GetRoad()->GetLanes(); i++)
                    {
                        auto& cars = road->GetCarsTo(i, crossId);
                        if (cars.size() > 0) //any car on this lane
                        {
                            //update the first car
                            SimCar* firstCar = &scenario.Cars()[(*cars.begin())->GetId()];
                            bool firstComplete = firstCar->GetSimState(time) == SimCar::SCHEDULED;
                            if (!firstComplete && firstCar != firstPriority)
                            {
                                ASSERT(firstPriority != 0);
                                int maxLength = std::min(firstCar->GetCar()->GetMaxSpeed(), road->GetRoad()->GetLimit());
                                if(maxLength > (road->GetRoad()->GetLength() - firstCar->GetCurrentPosition())) //will pass the cross
                                    firstCar->UpdateWaiting(time, firstPriority);
                                else
                                    firstCar->UpdatePosition(time, firstCar->GetCurrentPosition() + maxLength);
                            }
                            //update cars behind the first car
                            
                            for (auto carIte = cars.begin() + 1; carIte != cars.end(); carIte++)
                            {
                                SimCar* simCar = &scenario.Cars()[(*carIte)->GetId()];
                                SimCar* frontCar = &scenario.Cars()[(*(carIte - 1))->GetId()];
                                if (simCar->GetSimState(time) == SimCar::SCHEDULED)
                                    break;
                                if (simCar->GetSimState(time) == SimCar::WAITING && simCar->GetWaitingCar(time)->GetSimState(time) != SimCar::SCHEDULED)
                                    continue;
                                int maxLength = std::min(simCar->GetCar()->GetMaxSpeed(), road->GetRoad()->GetLimit());
                                int frontLength = frontCar->GetCurrentPosition() - simCar->GetCurrentPosition();
                                ASSERT(frontLength > 0);
                                if (frontCar->GetSimState(time) != SimCar::SCHEDULED && maxLength >= frontLength) //need wait the front car
                                {
                                    simCar->UpdateWaiting(time, frontCar);
                                    continue;
                                }
                                maxLength = std::min(maxLength, frontLength - 1);
                                simCar->UpdatePosition(time, simCar->GetCurrentPosition() + maxLength);
                            }
                        }
                    }
                    if (firstPriority == 0)
                        roadIte = roads.erase(roadIte);
                    else
                        roadIte++;
                }
                if (crossConflict)
                    break;
            }
            //corss schedule complete or not
            crossIte = roads.size() == 0 ? crosses.erase(crossIte) : (crossIte + 1);
        }
        if(scheduledCarsN - reachedCarsN == scenario.GetOnRoadCarsN())
            break;
        if (conflictFlag && scenario.GetOnRoadCarsN() > 0)
        {
            for (auto crossIte = Scenario::Crosses().begin(); crossIte != Scenario::Crosses().end(); crossIte++)
            {
                int crossId = crossIte->second->GetId();
                for (int i = (int)Cross::NORTH; i <= (int)Cross::WEST; i++)
                {
                    int id = crossIte->second->GetRoadId((Cross::DirectionType)i);
                    if (id >= 0)
                    {
                        SimRoad* road = &scenario.Roads()[id];
                        if (road->GetRoad()->GetEndCrossId() == crossId ||
                            (road->GetRoad()->GetStartCrossId() == crossId && road->GetRoad()->GetIsTwoWay()))
                        {
                            SimCar* firstPriority = PeekFirstPriorityCarOnRoad(time, scenario, road, crossId);
                            if (firstPriority != 0 && firstPriority->GetSimState(time) != SimCar::SCHEDULED)
                            {
                                ASSERT(firstPriority->GetSimState(time) == SimCar::WAITING);
                                for (int i = 1; i <= road->GetRoad()->GetLanes(); i++)
                                {
                                    auto& cars = road->GetCarsTo(i, crossId);
                                    if (cars.size() > 0) //any car on this lane
                                    {
                                        SimCar* firstCar = &scenario.Cars()[(*cars.begin())->GetId()];
                                        if (firstCar->GetSimState(time) != SimCar::SCHEDULED)
                                        {
                                            ASSERT(firstCar->GetSimState(time) == SimCar::WAITING && firstCar->GetWaitingCar(time)->GetSimState(time) == SimCar::WAITING);
                                            LOG("id " << firstCar->GetCar()->GetId()
                                                << " cross " << crossId
                                                << " road " << road->GetRoad()->GetId()
                                                << " lane " << i
                                                << " position " << firstCar->GetCurrentPosition()
                                                << " next " << firstCar->GetNextRoadId()
                                                << " dir " << (firstCar->GetNextRoadId() < 0 ? DIRECT : GetDirection(road->GetRoad()->GetId(), firstCar->GetNextRoadId()))
                                                << " waiting for " << firstCar->GetWaitingCar(time)->GetCar()->GetId()
                                                );
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            result.Conflict = true;
            break;
        }
    }
    
    if(!result.Conflict)
    {
        int getOutCounter = 0;
        //cars in garage
        for (auto ite = Scenario::Crosses().begin(); ite != Scenario::Crosses().end(); ite++)
        {
            int crossId = ite->second->GetId();
            auto findGarage = scenario.Garages().find(crossId);
            if (findGarage != scenario.Garages().end()) //find it!
            {
                for (auto garageCarIte = findGarage->second.begin(); garageCarIte != findGarage->second.end(); /* garageCarIte++ */)
                {
                    SimCar* car = *garageCarIte;
                    bool goout = false;
                    if (car->GetRealTime() <= time)
                    {
                        /* it's time to go! */
                        int roadId = car->GetNextRoadId();
                        ASSERT(roadId >= 0);
                        SimRoad* road = &scenario.Roads()[roadId];

                        /* do some things here */
                        int carSum = 0;
                        for(int i = 1; i <= road->GetRoad()->GetLanes(); i++)
                        {
                            carSum += road->GetCarsFrom(i, crossId).size();
                        }
                        double carAver = double(carSum)/double(road->GetRoad()->GetLanes());
                        if(carAver > 1.5)//road->GetRoad()->GetLength()/5)
                        {
                            //car->SetRealTime(car->GetRealTime() + 1);
                            garageCarIte++;
                            continue;
                        }

                        int maxLength = std::min(car->GetCar()->GetMaxSpeed(), road->GetRoad()->GetLimit());
                        for (int i = 1; i <= road->GetRoad()->GetLanes(); i++)
                        {
                            auto& cars = road->GetCarsFrom(i, crossId);
                            if (cars.size() > 0)
                            {
                                SimCar* lastCar = &scenario.Cars()[(*--cars.end())->GetId()];
                                ASSERT(lastCar->GetSimState(time) == SimCar::SCHEDULED);
                                ASSERT(lastCar->GetCurrentPosition() > 0);
                                if (lastCar->GetCurrentPosition() == 1)
                                    continue;
                                maxLength = std::min(maxLength, lastCar->GetCurrentPosition() - 1);
                            }
                            car->UpdateOnRoad(time, road->GetRoad(), i, road->IsFromOrTo(crossId), maxLength);
                            cars.push_back(car->GetCar());
                            car->SetRealTime(time);
                            goout = true;
                            break;
                        }
                        if (!goout)
                        {
                            LOG("car " << car->GetCar()->GetId() << " can not go on the road " << roadId << " @" << time);
                            //car->SetRealTime(time + 1);
                        }
                        else
                        {
                            getOutCounter++;
                            scenario.GetoutOnRoad();
                        }
                    }
                    garageCarIte = goout ? findGarage->second.erase(garageCarIte) : (garageCarIte + 1);
                }
                if (findGarage->second.size() == 0) //no car in garage
                    scenario.Garages().erase(findGarage);
            }
        }
        if (getOutCounter > 0)
            LOG("@" << time << " number of cars get on road form garage : " << getOutCounter);
    }
    ASSERT(result.Conflict || scheduledCarsN - reachedCarsN == scenario.GetOnRoadCarsN());
    return result;
}
