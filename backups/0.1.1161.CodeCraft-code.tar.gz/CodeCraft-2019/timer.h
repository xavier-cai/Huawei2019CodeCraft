#ifndef TIMER_H
#define TIMER_H

#include <time.h>

class Timer
{
private:
    static Timer& GetInstance();
    Timer();

    clock_t m_start;
    clock_t m_record;
    double m_max;

    double DoGetSpendTime(clock_t t) const;

    double DoSetRecordHere();
    double DoGetSpendTimeFormRecord() const;

    double DoGetSpendTime() const;
    double DoGetLeftTime() const;

public:
    static double SetRecordHere();
    static double GetSpendTimeFormRecord();

    static double GetSpendTime();
    static double GetLeftTime();
};//class Timer

#endif
