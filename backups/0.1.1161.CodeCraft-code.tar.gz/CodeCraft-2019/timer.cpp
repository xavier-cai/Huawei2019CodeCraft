#include "timer.h"
#include "stdlib.h"

Timer& Timer::GetInstance()
{
    static Timer instance;
    return instance;
}

Timer::Timer()
{
    srand(time(NULL));
    m_start = clock();
    m_record = m_start;
    m_max = 60;
}

double Timer::DoGetSpendTime(clock_t t) const
{
    return (double)(clock() - t) / CLOCKS_PER_SEC;
}

double Timer::DoSetRecordHere()
{
    m_record = clock();
    return GetSpendTime();
}

double Timer::DoGetSpendTimeFormRecord() const
{
    return DoGetSpendTime(m_record);
}

double Timer::DoGetSpendTime() const
{
    return DoGetSpendTime(m_start);
}

double Timer::DoGetLeftTime() const
{
    return m_max - DoGetSpendTime();
}

double Timer::SetRecordHere()
{
    return GetInstance().DoSetRecordHere();
}

double Timer::GetSpendTimeFormRecord()
{
    return GetInstance().DoGetSpendTimeFormRecord();
}

double Timer::GetSpendTime()
{
    return GetInstance().DoGetSpendTime();
}

double Timer::GetLeftTime()
{
    return GetInstance().DoGetLeftTime();
}
