#ifndef SCENARIO_H
#define SCENARIO_H

#include <map>
#include "car.h"
#include "cross.h"
#include "road.h"
#include <iostream>

class Scenario
{
private:
    std::map<int, Car*> m_cars;
    std::map<int, Cross*> m_crosses;
    std::map<int, Road*> m_roads;
    
    Scenario();
    static Scenario Instance;
    
    bool HandleCar(std::istream& is);
    bool HandleCross(std::istream& is);
    bool HandleRoad(std::istream& is);
    void DoInitialize();
    
public:
    ~Scenario();
    
    static void Initialize();
    static const std::map<int, Car*>& Cars();
    static const std::map<int, Cross*>& Crosses();
    static const std::map<int, Road*>& Roads();
    static Car* GetCar(const int& id);
    static Cross* GetCross(const int& id);
    static Road* GetRoad(const int& id);
    
};//class Scenario

#endif
